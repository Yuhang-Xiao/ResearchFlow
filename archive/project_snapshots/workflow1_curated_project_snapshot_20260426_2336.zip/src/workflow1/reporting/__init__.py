"""Paper reporting orchestration helpers."""
